package aDiary;

public class Main {
 
	
	public static void main(String[]args) {
		Menu menusito = new Menu();
		menusito.menuPrincipal();
	}
}
